/******************************************************************************
* echo_server.c                                                               *
*                                                                             *
* Description: This file contains the C source code for an echo server.  The  *
*              server runs on a hard-coded port and simply write back anything*
*              sent to it by connected clients.  It does not support          *
*              concurrent clients.                                            *
*                                                                             *
* Authors: Athula Balachandran <abalacha@cs.cmu.edu>,                         *
*          Wolf Richter <wolf@cs.cmu.edu>                                     *
*                                                                             *
*******************************************************************************/

#include <netinet/in.h>
#include <netinet/ip.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <parse.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <time.h>
#include <arpa/inet.h>
#include <pthread.h>  //TO get tid

#define ECHO_PORT 9999
#define BUF_SIZE 8192

int close_socket(int sock)
{
    if (close(sock))
    {
        fprintf(stderr, "Failed closing socket.\n");
        return 1;
    }
    return 0;
}
void write2log_error(pid_t pid_now, struct sockaddr_in cli, pthread_t tid, char* error_message) {
    char tmp[200];
    FILE* fp;
    time_t t_liso = time(NULL);
    struct tm* time_liso = gmtime(&t_liso);
    if((fp = fopen("./log/log.txt", "a")) == NULL) {
        printf("fail to open the file\n");
        return;
    }
    strftime(tmp, 128, "[%a %b %d %X %Y] ", time_liso);
    sprintf(tmp + strlen(tmp), "[core:error] [pid %ld:tid %ld] [client %s] %s\r\n", pid_now, tid, inet_ntoa(cli.sin_addr), error_message);
    fputs(tmp, fp);
    fclose(fp);
}
void write2log_access(struct sockaddr_in cli, Request* request, char* status_code, long int sz) {
    char tmp[200];
    FILE* fp;
    if((fp = fopen("./log/log.txt", "a")) == NULL) {
        printf("fail to open the file\n");
        return;
    }
    time_t t_liso = time(NULL);
    struct tm* time_liso = gmtime(&t_liso);
    sprintf(tmp, "%s - - ", inet_ntoa(cli.sin_addr));
    strftime(tmp + strlen(tmp), 128, "[%d/%b/%Y:%X %Z] ", time_liso);
    sprintf(tmp + strlen(tmp), "\"%s ./static_site%sindex.html %s\" %s ", request->http_method, request->http_uri, request->http_version, status_code);
    if(sz > 0) sprintf(tmp + strlen(tmp), "%ld\r\n", sz);
    else strcat(tmp, "-\r\n");
    fputs(tmp, fp);
    fclose(fp);
}
void get_header(Request* request, char* target, char* toget) {
    for(int i = 0;i < request->header_count;i++) {
        if(!strcmp(target, request->headers[i].header_name)) {
            strcpy(toget, request->headers[i].header_value);
            return;
        }
    }
}
void seek_for_type(char* now, char* type) {
    int len = strlen(now);
    for(int i = 1;i < len;i++) {
        if(now[i] == '.') {
            if(!strcmp(now + i + 1, "html")) strcpy(type, "text/html");
            else if(!strcmp(now + i + 1, "css")) strcpy(type, "text/css");
            else if(!strcmp(now + i + 1, "png")) strcpy(type, "image/png");
            else if(!strcmp(now + i + 1, "jpeg")) strcpy(type, "image/jpeg");
            else if(!strcmp(now + i + 1, "gif")) strcpy(type, "image/gif");
            else strcpy(type, "unknown");
            return;
        }
    }
    strcpy(type, "unknown");
}
int main(int argc, char* argv[])
{
    int sock, client_sock;
    ssize_t readret;
    socklen_t cli_size;
    struct sockaddr_in addr, cli_addr;
    char buf[BUF_SIZE];
    char bufrev[1];
    fprintf(stdout, "----- Liso Server -----\n");
    
    /* all networked programs must create a socket */
    if ((sock = socket(PF_INET, SOCK_STREAM, 0)) == -1)
    {
        fprintf(stderr, "Failed creating socket.\n");
        return EXIT_FAILURE;
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(ECHO_PORT);
    addr.sin_addr.s_addr = INADDR_ANY;

    /* servers bind sockets to ports---notify the OS they accept connections */
    if (bind(sock, (struct sockaddr *) &addr, sizeof(addr)))
    {
        close_socket(sock);
        fprintf(stderr, "Failed binding socket.\n");
        return EXIT_FAILURE;
    }


    if (listen(sock, 5))
    {
        close_socket(sock);
        fprintf(stderr, "Error listening on socket.\n");
        return EXIT_FAILURE;
    }

    /* finally, loop waiting for input and then write it back */
    while (1)
    {
        memset(buf, 0, sizeof buf);
        cli_size = sizeof(cli_addr);
        if ((client_sock = accept(sock, (struct sockaddr *) &cli_addr,
                                    &cli_size)) == -1)
        {
            close(sock);
            fprintf(stderr, "Error accepting connection.\n");
            return EXIT_FAILURE;
        }

        readret = 0;

        int now = 0, len = 0;
        while(recv(client_sock, bufrev, 1, 0) >= 1)
        {
            buf[len++] = bufrev[0];
            if(len == 1 && buf[0] == '\r') {
                while(recv(client_sock, buf, BUF_SIZE, MSG_DONTWAIT) >= 1);
                break;
            }
            if(len == BUF_SIZE) {
                strcpy(buf, "HTTP/1.1 400 Bad request\r\n\r\n");
                while(recv(client_sock, buf, BUF_SIZE, MSG_DONTWAIT) >= 1);
                write2log_error(getpid(), cli_addr, pthread_self(), "HTTP/1.1 400 Bad request");
                break;
            }
            if((now == 0 || now == 2) && bufrev[0] == '\r') now++;
            else if((now == 1 || now == 3) && bufrev[0] == '\n') now++;
            else now = 0;
            if(now != 4) continue;
            readret = len;
            len = now = 0;
            Request *request = parse(buf, readret, client_sock);
            if(!request) {
                strcpy(buf, "HTTP/1.1 400 Bad request\r\n\r\n");
                write2log_error(getpid(), cli_addr, pthread_self(), "HTTP/1.1 400 Bad request");
            } else if(strcmp(request->http_method, "GET") && strcmp(request->http_method, "POST") && strcmp(request->http_method, "HEAD")) {
                strcpy(buf, "HTTP/1.1 501 Not Implemented\r\n\r\n");
                write2log_error(getpid(), cli_addr, pthread_self(), "HTTP/1.1 501 Not Implemented");
            } else if(strcmp(request->http_version, "HTTP/1.1")) {
                strcpy(buf, "HTTP/1.1 505 HTTP Version not supported\r\n\r\n");
                write2log_error(getpid(), cli_addr, pthread_self(), "HTTP/1.1 505 HTTP Version not supported");
            }  else if(strcmp(request->http_method, "POST")){
                    char file_path[200] = "./static_site";
                    strcat(file_path, request->http_uri);
                    strcat(file_path, "index.html");
                    strcpy(buf,  "HTTP/1.1 200 OK\r\n");
                    int flg = 1;
                    //server
                    strcat(buf, "Server: liso/1.0\r\n");
                    //date
                    strcat(buf, "Date: ");
                    time_t t_liso = time(NULL);
                    struct tm* time_liso = gmtime(&t_liso);
                    strftime(buf + strlen(buf), 128, "%a, %d %b %Y %X %Z", time_liso);
                    strcat(buf + strlen(buf), "\r\n");
                    //content-length*/
                    struct stat* mystat = (struct stat*)malloc(sizeof(struct stat));
                    if(stat(file_path, mystat) < 0) {
                        strcpy(buf,  "HTTP/1.1 404 Not Found\r\n\r\n");
                        flg = 0;
                        write2log_error(getpid(), cli_addr, pthread_self(), "HTTP/1.1 404 Not Found");
                    }
                    if(flg) {
                        long int len = (strcmp(request->http_method, "GET")) ? 0 : mystat->st_size;
                        write2log_access(cli_addr, request, "200", len);
                        strcat(buf, "Content-Length: ");
                        sprintf(buf + strlen(buf), "%ld", mystat->st_size);
                        strcat(buf, "\r\n");
                        //content-type
                        char tmp[200];
                        strcat(buf, "Content-Type: ");
                        seek_for_type(file_path, tmp);
                        strcat(buf, tmp);
                        strcat(buf, "\r\n");
                        //last-modified
                        strcat(buf, "Last-Modified: ");
                        t_liso = mystat->st_mtime;
                        time_liso = gmtime(&t_liso);
                        strftime(buf + strlen(buf), 128, "%a, %d %b %Y %X %Z", time_liso);
                        strcat(buf + strlen(buf), "\r\n");
                        free(mystat);
                        //connection
                        get_header(request, "Connection", tmp);
                        strcat(buf, "Connection: ");
                        strcat(buf, tmp);
                        strcat(buf, "\r\n\r\n");
                    }
                    if(flg && !strcmp(request->http_method, "GET")) {
                        int fd_in = open(file_path, O_RDONLY);
                        readret += read(fd_in, buf + strlen(buf), BUF_SIZE);
                    } 
                } else {
                    write2log_access(cli_addr, request, "200", 0);
                    }
            if(request) {
                free(request->headers);
                free(request);
            }
            readret = strlen(buf);
            if (send(client_sock, buf, readret, 0) != readret)
            {
                close_socket(client_sock);
                close_socket(sock);
                fprintf(stderr, "Error sending to client.\n");
                return EXIT_FAILURE;
            }
            memset(buf, 0, BUF_SIZE);
        }

        if (readret == -1)
        {
            close_socket(client_sock);
            close_socket(sock);
            fprintf(stderr, "Error reading from client socket.\n");
            return EXIT_FAILURE;
        }

        if (close_socket(client_sock))
        {
            close_socket(sock);
            fprintf(stderr, "Error closing client socket.\n");
            return EXIT_FAILURE;
        }
    }

    close_socket(sock);
    return EXIT_SUCCESS;
}